import requests

API_KEY = '44665334856e503faa61ed95aef1087d'  

def get_weather(city):
    url = f"http://api.weatherstack.com/current?access_key={API_KEY}&query={city}"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if 'current' in data:
            return {
                'location': data['location']['name'],
                'country': data['location']['country'],
                'temperature': data['current']['temperature'],
                'description': data['current']['weather_descriptions'][0],
                'humidity': data['current']['humidity'],
                'wind_speed': data['current']['wind_speed']
            }
        else:
            return {"error": "Could not retrieve weather data. Please check the city name."}
    else:
        return {"error": "Unable to connect to the weather service."}

def main():
    city = input("Enter the city name: ")
    weather = get_weather(city)
    
    if 'error' in weather:
        print(f"Error: {weather['error']}")
    else:
        print(f"Weather in {weather['location']}, {weather['country']}:")
        print(f"Temperature: {weather['temperature']}°C")
        print(f"Description: {weather['description']}")
        print(f"Humidity: {weather['humidity']}%")
        print(f"Wind Speed: {weather['wind_speed']} km/h")

if __name__ == "__main__":
    main()